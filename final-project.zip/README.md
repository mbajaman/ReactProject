# ReactProject
The following README provides instructions on how to make sure the app runs.
Make sure you 'npm install' in the project director prior to running the application.

Libraries Used:
react-native-elements
react-navigation
react-native-maps

-- Create Reminders and edit it to set your own title, notes, and images. Also includes GPS/Map viewing.